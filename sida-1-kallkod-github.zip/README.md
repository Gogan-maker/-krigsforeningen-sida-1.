# Sida 1 – Nödradio

Källkod för webbutiken. Gränssnittet ligger i dist/. Stripe Checkout, webhooken och den skyddade ordervyn ligger i server/. Databasmigreringen finns i drizzle/.

## Bygg

Använd Node.js 24 eller senare. Kör npm ci och sedan npm run build. Den körbara Worker-filen byggs till dist/server/index.js.

## Drift

Den fullständiga kassan kräver en Cloudflare Worker-kompatibel servermiljö och en D1-databas med bindningen DB. Tillämpa SQL-migreringen innan kassan öppnas. Se [Stripe och driftinställningar](STRIPE_INTEGRATION_TODO.md) för variabelnamn, webhook och verifiering.

GitHub innehåller källkoden. Befintlig Sites-drift, domän, databas och skyddade servervärden konfigureras separat.
