CREATE TABLE checkout_orders (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  quantity INTEGER NOT NULL,
  recipients TEXT NOT NULL,
  total_ore INTEGER NOT NULL,
  livemode INTEGER NOT NULL,
  stripe_session_id TEXT UNIQUE,
  paid_at TEXT
);
