const pageSize = 50;
const maxCursor = Number.MAX_SAFE_INTEGER;
const money = new Intl.NumberFormat('sv-SE', { style: 'currency', currency: 'SEK' });
const privateHeaders = {
  'Cache-Control': 'no-store',
  'Referrer-Policy': 'no-referrer',
  'X-Content-Type-Options': 'nosniff',
  'Content-Security-Policy': "default-src 'none'; style-src 'self'; frame-ancestors 'none'; base-uri 'none'",
};

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[char]);
}

function page(title, body, status = 200) {
  return new Response(
    '<!doctype html><html lang="sv"><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width, initial-scale=1">' +
    '<title>' + title + '</title></head><body><main><h1>' + title + '</h1>' +
    body + '</main></body></html>',
    { status, headers: { ...privateHeaders, 'Content-Type': 'text/html; charset=utf-8' } },
  );
}

export function renderOrderStatus(order) {
  const returnLink = '<p><a href="/">Tillbaka till Krigsföreningen</a></p>';
  if (!order) return page('Orderstatus', '<p>Beställningen kunde inte hittas.</p>' + returnLink, 404);

  const number = '<p>Ordernummer ' + escapeHtml(order.id) + '</p>';
  if (!order.paid_at) {
    return page('Vi väntar på betalningsbekräftelsen', number +
      '<p>Betalningen har ännu inte bekräftats. Uppdatera sidan om en stund.</p>' + returnLink);
  }
  return page('Tack för din beställning!', '<p>Betalningen är bekräftad.</p>' + number +
    '<p>Antal nödradioapparater ' + escapeHtml(order.quantity) + '</p>' +
    '<p>Betalt belopp ' + money.format(order.total_ore / 100) + '</p>' + returnLink);
}

function shipments(order) {
  const recipients = JSON.parse(order.recipients);
  return recipients.map(recipient => ({
    ...recipient,
    country: recipient.country ?? 'SE',
    quantity: recipients.length === 1 ? order.quantity : 1,
  }));
}

async function paidOrders(db, before, limit) {
  const result = await db.prepare(
    'SELECT rowid AS cursor, id, quantity, recipients, total_ore, paid_at ' +
    'FROM checkout_orders WHERE livemode = 1 AND paid_at IS NOT NULL AND rowid < ? ' +
    'ORDER BY rowid DESC LIMIT ?',
  ).bind(before, limit).all();
  return result.results;
}

function csvCell(value) {
  const text = String(value ?? '');
  const safe = /^\s*[=+\-@\t\r\n\uFF1D\uFF0B\uFF0D\uFF20]/u.test(text) ? "'" + text : text;
  return '"' + safe.replaceAll('"', '""') + '"';
}

function csvLine(values) {
  return values.map(csvCell).join(',') + '\r\n';
}

function exportOrders(db) {
  const encode = new TextEncoder();
  let cursor = maxCursor;
  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(encode.encode('\ufeff' + csvLine([
        'Ordernummer', 'Betald UTC', 'Antal i ordern', 'Ordertotal SEK', 'Antal till mottagaren',
        'Namn', 'Telefon', 'Adress', 'Postnummer', 'Stad', 'Landkod',
      ])));
    },
    async pull(controller) {
      const orders = await paidOrders(db, cursor, pageSize);
      const rows = orders.flatMap(order => shipments(order).map(recipient => csvLine([
        order.id, order.paid_at, order.quantity, (order.total_ore / 100).toFixed(2), recipient.quantity,
        recipient.name, recipient.phone, recipient.street, recipient.postcode, recipient.city, recipient.country,
      ])));
      if (rows.length) controller.enqueue(encode.encode(rows.join('')));
      if (orders.length < pageSize) controller.close();
      else cursor = orders.at(-1).cursor;
    },
  });
  return new Response(stream, { headers: {
    ...privateHeaders,
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': 'attachment; filename="betalda-bestallningar.csv"',
  } });
}

export async function renderOrderAdmin(request, url, env) {
  if (request.method !== 'GET') {
    return new Response(null, { status: 405, headers: { ...privateHeaders, Allow: 'GET' } });
  }
  const adminEmail = env.ORDERS_ADMIN_EMAIL?.trim().toLowerCase();
  if (!env.DB || !adminEmail) return page('Ordervyn är inte konfigurerad', '', 503);

  if (!request.headers.get('oai-authenticated-user-id')) {
    return page('Logga in för att visa beställningar',
      '<p><a target="_top" href="/signin-with-chatgpt?return_to=%2Fadmin%2Forders">Logga in med ChatGPT</a></p>', 401);
  }
  if (request.headers.get('oai-authenticated-user-email')?.trim().toLowerCase() !== adminEmail) {
    return page('Åtkomst nekad', '', 403);
  }

  if (url.pathname.endsWith('.csv')) return exportOrders(env.DB);
  const before = Number(url.searchParams.get('before') || maxCursor);
  if (!Number.isSafeInteger(before) || before < 1) return page('Ogiltig sida', '', 400);
  const orders = await paidOrders(env.DB, before, pageSize + 1);
  const rows = orders.slice(0, pageSize).map(order => {
    const addresses = shipments(order).map(recipient => '<li>' + [
      recipient.quantity + ' st', recipient.name, recipient.street,
      recipient.postcode + ' ' + recipient.city, recipient.country, recipient.phone,
    ].map(escapeHtml).join(' · ') + '</li>').join('');
    return '<article><h2>Order ' + escapeHtml(order.id) + '</h2><p>' +
      escapeHtml(order.paid_at) + ' UTC · ' + escapeHtml(order.quantity) + ' st · ' +
      money.format(order.total_ore / 100) + '</p><ul>' + addresses + '</ul></article>';
  }).join('');
  const next = orders.length > pageSize
    ? '<p><a href="?before=' + orders[pageSize - 1].cursor + '">Äldre beställningar</a></p>' : '';
  return page('Betalda beställningar',
    '<p><a href="/admin/orders.csv">Exportera betalda beställningar som CSV</a></p>' +
    (rows || '<p>Inga betalda beställningar.</p>') + next);
}
