import { createServer } from 'node:http';
import Stripe from 'stripe';

const checkoutPath = '/api/create-checkout-session';
const defaultDomain = 'http://localhost:3000';
const defaultPriceId = 'price_...';

export function createCheckoutHandler({
  stripe,
  domain = defaultDomain,
  priceId = defaultPriceId,
}) {
  return async function handleCheckout(request, response) {
    if (request.url !== checkoutPath) {
      response.writeHead(404).end();
      return;
    }

    if (request.method !== 'POST') {
      response.writeHead(405, { Allow: 'POST' }).end();
      return;
    }

    const headers = {
      'Cache-Control': 'no-store',
      'Content-Type': 'text/plain; charset=utf-8',
    };

    if (!stripe || !/^price_[A-Za-z0-9]+$/.test(priceId)) {
      response.writeHead(503, headers).end('Kassan behöver konfigureras.');
      return;
    }

    try {
      const origin = new URL(domain).origin;
      const session = await stripe.checkout.sessions.create({
        ui_mode: 'hosted_page',
        mode: 'payment',
        billing_address_collection: 'auto',
        phone_number_collection: { enabled: false },
        automatic_tax: { enabled: false },
        allow_promotion_codes: false,
        submit_type: 'auto',
        integration_identifier: 'hosted_web_0002',
        origin_context: 'web',
        success_url: origin + '/success?session_id={CHECKOUT_SESSION_ID}',
        cancel_url: origin,
        line_items: [{ price: priceId, quantity: 1 }],
      });

      if (!session.url) {
        response.writeHead(502, headers).end('Betalningssidan kunde inte öppnas.');
        return;
      }

      response.writeHead(303, {
        'Cache-Control': 'no-store',
        Location: session.url,
      }).end();
    } catch {
      response.writeHead(502, headers).end('Kassan kunde inte öppnas. Försök igen.');
    }
  };
}

if (import.meta.main) {
  const key = process.env.STRIPE_SECRET_KEY;
  const stripe = key ? new Stripe(key) : null;
  const handler = createCheckoutHandler({
    stripe,
    domain: process.env.DOMAIN,
    priceId: process.env.STRIPE_PRICE_ID,
  });

  createServer(handler).listen(Number(process.env.PORT || 3000), '127.0.0.1');
}
