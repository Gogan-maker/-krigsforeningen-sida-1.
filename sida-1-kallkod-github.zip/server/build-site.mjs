import { readFile } from 'node:fs/promises';
import { build } from 'esbuild';

const types = {
  'index.html': 'text/html; charset=utf-8',
  'app.js': 'text/javascript; charset=utf-8',
  'pricing.mjs': 'text/javascript; charset=utf-8',
  'address-lookup.js': 'text/javascript; charset=utf-8',
  'style.css': 'text/css; charset=utf-8',
  'assets/nodradio-corner-flag.png': 'image/png',
  'assets/apple-pay.svg': 'image/svg+xml',
  'assets/klarna.svg': 'image/svg+xml',
};

const entries = await Promise.all(Object.entries(types).map(async ([path, type]) => {
  const bytes = await readFile(new URL('../dist/' + path, import.meta.url));
  return ['/' + path, { type, base64: bytes.toString('base64') }];
}));

await build({
  entryPoints: ['server/site-checkout.mjs'],
  outfile: 'dist/server/index.js',
  bundle: true,
  platform: 'browser',
  conditions: ['workerd'],
  format: 'esm',
  plugins: [{
    name: 'site-assets',
    setup(builder) {
      builder.onResolve({ filter: /^site-assets$/ }, args => ({ path: args.path, namespace: 'site-assets' }));
      builder.onLoad({ filter: /.*/, namespace: 'site-assets' }, () => ({
        contents: 'export const assets = ' + JSON.stringify(Object.fromEntries(entries)),
      }));
    },
  }],
});
