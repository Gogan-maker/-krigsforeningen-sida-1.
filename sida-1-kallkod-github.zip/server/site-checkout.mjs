import Stripe from 'stripe';
import { calculateQuote } from '../dist/pricing.mjs';
import { assets } from 'site-assets';
import { renderOrderAdmin, renderOrderStatus } from './orders.mjs';

const noStore = { 'Cache-Control': 'no-store' };
const json = (data, status = 200) => Response.json(data, { status, headers: noStore });
const stripeFor = env => new Stripe(env.STRIPE_SECRET_KEY, {
  httpClient: Stripe.createFetchHttpClient(),
});

function decodeAsset(encoded) {
  const decoded = atob(encoded);
  const bytes = new Uint8Array(decoded.length);
  for (let index = 0; index < decoded.length; index++) bytes[index] = decoded.charCodeAt(index);
  return bytes;
}

function checkoutSettings(env) {
  const mode = env.STRIPE_CHECKOUT_MODE;
  const shipping = env.SHIPPING_PER_ADDRESS_ORE;
  const live = mode === 'live';
  const key = env.STRIPE_SECRET_KEY || '';
  if (
    !['test', 'live'].includes(mode) || !env.DB ||
    !new RegExp('^(?:rk|sk)_' + mode + '_').test(key) ||
    !/^whsec_.+/.test(env.STRIPE_WEBHOOK_SECRET || '') ||
    !/^price_[A-Za-z0-9]+$/.test(env.STRIPE_PRICE_ID || '') ||
    !/^prod_[A-Za-z0-9]+$/.test(env.STRIPE_PRODUCT_ID || '') ||
    !/^\d{1,6}$/.test(shipping || '')
  ) return null;
  return { live, shippingPerAddress: Number(shipping) };
}

function orderFrom(body) {
  const quote = calculateQuote(body.quantity);
  const count = body.separate === true ? quote.quantity : 1;
  if (!Array.isArray(body.recipients) || body.recipients.length !== count) {
    throw new Error('Ange rätt antal leveransadresser.');
  }
  const fields = {
    name: /^.{1,120}$/,
    street: /^.{1,120}$/,
    postcode: /^[0-9]{3} ?[0-9]{2}$/,
    city: /^.{1,120}$/,
    phone: /^[+0-9() .-]{6,25}$/,
  };
  const recipients = body.recipients.map(recipient => Object.fromEntries(
    Object.entries(fields).map(([field, pattern]) => {
      const value = typeof recipient?.[field] === 'string' ? recipient[field].trim() : '';
      if (!pattern.test(value)) throw new Error('Kontrollera namn, adress, postnummer, stad och telefonnummer.');
      return [field, value];
    }),
  ));
  if (body.recipients.some(recipient => recipient?.country !== 'SE')) {
    throw new Error('Ange Sverige som leveransland.');
  }
  for (const recipient of recipients) recipient.country = 'SE';
  return { ...quote, recipients };
}

async function createSession(request, env, settings, stripe) {
  const url = new URL(request.url);
  if (request.headers.get('origin') !== url.origin) return json({ error: 'Ogiltig begäran.' }, 403);
  let order;
  let expectedTotal;
  try {
    const body = await request.text();
    if (body.length > 18000) return json({ error: 'Beställningen är för stor.' }, 413);
    const input = JSON.parse(body);
    order = orderFrom(input);
    expectedTotal = input.expectedTotal;
  } catch {
    return json({ error: 'Kontrollera antal och leveransadresser.' }, 400);
  }

  const shipping = settings.shippingPerAddress * order.recipients.length;
  const total = order.total * 100 + shipping;
  if (expectedTotal !== total) {
    return json({ error: 'Summan har ändrats. Ladda om sidan och granska beställningen igen.' }, 409);
  }
  const orderId = crypto.randomUUID();
  const lineItems = [{ price: env.STRIPE_PRICE_ID, quantity: 1 }];
  if (order.quantity > 1) {
    lineItems.push({
      price_data: { currency: 'sek', unit_amount: 24900, product: env.STRIPE_PRODUCT_ID },
      quantity: order.quantity - 1,
    });
  }
  if (shipping) {
    lineItems.push({
      price_data: { currency: 'sek', unit_amount: shipping, product_data: { name: 'Frakt' } },
      quantity: 1,
    });
  }
  const session = await stripe.checkout.sessions.create({
    ui_mode: 'hosted_page',
    mode: 'payment',
    billing_address_collection: 'auto',
    phone_number_collection: { enabled: false },
    automatic_tax: { enabled: false },
    adaptive_pricing: { enabled: false },
    allow_promotion_codes: false,
    submit_type: 'auto',
    integration_identifier: 'hosted_web_0002',
    origin_context: 'web',
    success_url: url.origin + '/orderstatus?session_id={CHECKOUT_SESSION_ID}',
    cancel_url: url.origin + '/#bestall',
    client_reference_id: orderId,
    line_items: lineItems,
  });
  if (!session.url || session.amount_total !== total ||
      session.currency !== 'sek' || session.livemode !== settings.live) {
    return json({ error: 'Beloppet i Stripe stämmer inte. Försök senare.' }, 502);
  }
  await env.DB.prepare(`INSERT INTO checkout_orders
    (id, quantity, recipients, total_ore, livemode, stripe_session_id)
    VALUES (?, ?, ?, ?, ?, ?)`).bind(
    orderId, order.quantity, JSON.stringify(order.recipients), total, Number(settings.live), session.id,
  ).run();
  return json({ url: session.url });
}

async function receiveWebhook(request, env, settings, stripe) {
  const signature = request.headers.get('stripe-signature');
  if (!signature) return json({ error: 'Signatur krävs.' }, 400);
  let event;
  try {
    event = await stripe.webhooks.constructEventAsync(
      await request.text(), signature, env.STRIPE_WEBHOOK_SECRET,
      undefined, Stripe.createSubtleCryptoProvider(),
    );
  } catch {
    return json({ error: 'Ogiltig signatur.' }, 400);
  }
  const session = event.data.object;
  if (['checkout.session.completed', 'checkout.session.async_payment_succeeded'].includes(event.type) &&
      event.livemode === settings.live && session.payment_status === 'paid' &&
      session.currency === 'sek' && typeof session.client_reference_id === 'string') {
    await env.DB.prepare(`UPDATE checkout_orders SET paid_at = CURRENT_TIMESTAMP
      WHERE paid_at IS NULL AND id = ? AND stripe_session_id = ? AND total_ore = ? AND livemode = ?`).bind(
      session.client_reference_id, session.id, session.amount_total, Number(settings.live),
    ).run();
  }
  return json({ received: true });
}

async function orderStatus(url, env) {
  const id = url.searchParams.get('session_id') || '';
  const order = env.DB && /^cs_(?:test|live)_[A-Za-z0-9]+$/.test(id)
    ? await env.DB.prepare('SELECT id, quantity, total_ore, paid_at FROM checkout_orders WHERE stripe_session_id = ?').bind(id).first()
    : null;
  return renderOrderStatus(order);
}

export function siteHandler(makeStripe = stripeFor) {
  return async (request, env) => {
    const url = new URL(request.url);
    try {
      const settings = checkoutSettings(env);
      switch (url.pathname) {
        case '/api/checkout-status':
          return json(settings
            ? { enabled: true, test: !settings.live, shippingPerAddress: settings.shippingPerAddress }
            : { enabled: false });
        case '/api/create-checkout-session':
        case '/api/stripe-webhook':
          if (request.method !== 'POST') return new Response(null, { status: 405, headers: { Allow: 'POST' } });
          if (!settings) return json({ error: 'Kassan är ännu inte öppen.' }, 503);
          return await (url.pathname.endsWith('stripe-webhook')
            ? receiveWebhook(request, env, settings, makeStripe(env))
            : createSession(request, env, settings, makeStripe(env)));
        case '/orderstatus':
          return await orderStatus(url, env);
        case '/admin/orders':
        case '/admin/orders.csv':
          return await renderOrderAdmin(request, url, env);
        default: {
          const path = url.pathname === '/' ? '/index.html' : url.pathname;
          const asset = Object.hasOwn(assets, path) ? assets[path] : null;
          if (!asset) return new Response('Sidan hittades inte.', { status: 404 });
          return new Response(request.method === 'HEAD' ? null : decodeAsset(asset.base64), {
            headers: { 'Content-Type': asset.type },
          });
        }
      }
    } catch {
      return json({ error: 'Kassan kunde inte öppnas. Försök igen.' }, 502);
    }
  };
}

export default { fetch: siteHandler() };
