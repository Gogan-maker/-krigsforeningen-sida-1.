# Stripe Checkout för sida 1

Beställningsformuläret på sida 1 använder [server/site-checkout.mjs](server/site-checkout.mjs) i Sites. Formuläret visar en knapp till Stripe när kassan är konfigurerad. Leveranserna använder Sverige och svenska postnummer. Servern räknar ut pris och frakt, lagrar leveransadresserna i D1 och kopplar betalningen till beställningen. Den signerade webhooken markerar ordern som betald. [server/checkout.mjs](server/checkout.mjs) är den separata exempelservern från den första integreringen.

## Värden att fylla i

**Fil med exempelvärden:** [server/checkout.mjs](server/checkout.mjs)

| Fält | Nuvarande värde | Så ställer du in det |
|---|---|---|
| `mode` | `payment` | Behåll `payment` för nödradions engångsköp. |
| `success_url` | `http://localhost:3000/success?session_id={CHECKOUT_SESSION_ID}` | Sätt `DOMAIN` till den riktiga webbplatsens HTTPS-adress och bygg en sida på `/success`. Behåll platshållaren `{CHECKOUT_SESSION_ID}`. |
| `cancel_url` | `http://localhost:3000` | Sätt `DOMAIN` till webbplatsens HTTPS-adress. Anpassa returvägen till beställningsdelen vid anslutning till sida 1. |
| `line_items[0].price` | `price_...` | Sätt `STRIPE_PRICE_ID` till pris-ID:t för Nödradio 299 SEK från [Stripe Dashboard](https://dashboard.stripe.com/prices), med samma test- eller liveläge som serverns nyckel. |
| `line_items[0].quantity` | `1` | Exemplet gäller en radio. Räkna ut antal och prissättningen för extra radioapparater på servern när beställningsformuläret kopplas in. |

## Inställningar från Checkout Studio

**Fil:** [server/checkout.mjs](server/checkout.mjs)

| Parameter | Värde |
|---|---|
| `ui_mode` | `hosted_page` med Stripe SDK 23.1.0. SDK-versioner under 21 använder `hosted`. |
| `billing_address_collection` | `auto` |
| `phone_number_collection.enabled` | `false` |
| `automatic_tax.enabled` | `false` |
| `allow_promotion_codes` | `false` |
| `submit_type` | `auto` |
| `integration_identifier` | `hosted_web_0002` |
| `origin_context` | `web` |

`payment_method_collection` ingår enbart för abonnemang enligt uppgiftens regel. Stripe-klienten använder SDK:ns API-version.

## Lokal installation och test

1. Kör `npm ci` med Node.js 24 eller senare. [package.json](package.json) och [package-lock.json](package-lock.json) anger beroendena.
2. Sätt `STRIPE_SECRET_KEY` till en begränsad nyckel för GA Bilverkstad AB:s Stripe-sandlåda, med behörighet att skapa Checkout Sessions. Lägg nyckeln i serverns hemliga miljövariabler. Använd `STRIPE_PRICE_ID` för ett pris i samma sandlåda. `DOMAIN` är ursprunget för returadresserna. För en lokal körning kan du behålla `http://localhost:3000`.
3. Starta med `npm run start:checkout`. Servern lyssnar lokalt på port 3000 om `PORT` inte anges.
4. Gör ett POST-anrop till `/api/create-checkout-session`, exempelvis med `curl -i -X POST http://localhost:3000/api/create-checkout-session`. Öppna Checkout-adressen som kommer i svarets `Location`-header. I sandlådan kan du använda testkortet `4242 4242 4242 4242`, ett framtida utgångsdatum och valfri tresiffrig CVC. Se [Stripes testdokumentation](https://docs.stripe.com/testing).
5. Kontrollera att Stripe visar en nödradio för 299 SEK. Retursidorna är exempelvärden och hanteras först när servern kopplas till webbplatsen. Denna endpoint behöver ingen publik Stripe-nyckel.

## Aktivera kassan på sida 1

GA Bilverkstad AB:s livekonto är anslutet till ChatGPT. Webbplatsens server behöver separata Stripe-behörigheter. Lägg in hemligheter direkt i Sites skyddade miljövariabler.

| Miljövariabel | Vad som ska anges |
|---|---|
| `STRIPE_CHECKOUT_MODE` | `live` för GA Bilverkstad AB:s riktiga betalningar. |
| `STRIPE_SECRET_KEY` | Hemlig, begränsad nyckel med behörighet att skapa Checkout Sessions i rätt Stripe-läge. |
| `STRIPE_WEBHOOK_SECRET` | Hemlig signeringsnyckel för rätt Stripe-läge och webhook-adress. |
| `STRIPE_PRICE_ID` | Det aktiva engångspriset på 299 kr. |
| `STRIPE_PRODUCT_ID` | Nödradions produkt-ID för samma Stripe-konto och läge. |
| `SHIPPING_PER_ADDRESS_ORE` | Frakt i öre per leveransadress. Ange `0` om frakten ska vara gratis. |
| `ORDERS_ADMIN_EMAIL` | Den e-postadress som ägaren loggar in med i ChatGPT. Endast den inloggningen får visa och exportera betalda beställningar. |

1. Skapa en begränsad live-API-nyckel för Checkout Sessions i Stripe Dashboard under Developers → API keys. Ange nyckeln som `STRIPE_SECRET_KEY` i Sites skyddade miljövariabler.
2. Skapa en Stripe-webhook i Workbench → Webhooks på webbplatsens befintliga HTTPS-adress följd av `/api/stripe-webhook`. Välj `checkout.session.completed` och `checkout.session.async_payment_succeeded`. Spara signeringshemligheten som `STRIPE_WEBHOOK_SECRET`. Stripe måste kunna nå adressen utan ChatGPT-inloggning. Nuvarande åtkomstläge är begränsat. Om det även skyddar webhooken krävs publik åtkomst eller en separat publik vidarebefordran som bevarar Stripe-signaturen och den oförändrade begäran. Detta kräver ingen ändring i DNS.
3. Bygg med `npm ci` och `npm run build`. Sites behöver D1-bindningen `DB` och [ordermigreringen](drizzle/0000_checkout_orders.sql). Versionen ska sparas utan publicering tills betalningsflödet är granskat.
4. Kontrollera en och två radioapparater, frakt, flera mottagare, avbruten kassa och att en signerad webhook för rätt belopp uppdaterar orderstatus. Kontrollera att Stripe kan leverera webhooken innan kassan öppnas. Ett provköp på livekontot debiterar riktiga pengar.
5. Öppna `/admin/orders` för att granska betalda liveordrar och exportera dem som CSV. CSV-filen har en rad per leveransadress och separat antal till varje mottagare. Ordersumman återges på varje rad som hör till samma order.
6. Stripe visar de betalmetoder som är aktiva och tillgängliga för kunden. En separat egen fakturafunktion ingår inte i Stripe Checkout-flödet.

[Stripe Support](https://support.stripe.com) · [Stripe MCP](https://docs.stripe.com/mcp)
